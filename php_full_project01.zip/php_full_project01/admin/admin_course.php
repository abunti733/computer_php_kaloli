<?php
require("db_con.php");
if(isset($_POST["submit"])){
    $name = $_POST['course'];

    $insert = mysqli_query($db_con , "INSERT INTO `about`( `course`) VALUES ('$name')");
    echo "ok";
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Course</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
<div class="dasboard">
<h1><i class="fa-solid fa-dollar-sign  px-2" style="font-size:35px"></i>Create Course <small> Statistics Overview</small></h1>
<div class="p-2" style="background:#f5f5f5;"><a href="admin_index.php?page=admin_dashboard"><i class="fa-solid fa-gauge"></i>Dashboard    <i class="fa-solid fa-people-group px-2" style="font-size:18px;"></i>Create Course</a></div>
</div>


  <form action="" method="post" style="margin-top:20px;">
  <div class="input_group">
                <label for="">Course <span>*</span></label><br/>
               <input type="text" name="course" >
       
              </div>



     <!-- course information end -->
        <div class="submit_btn" id="submit_btn">
          <input type="submit" value="Submit" name="submit" id="submit" style="margin-top:20px;">
        </div>
        
    </form>


</body>
</html>