
<?php
require("db_con.php");


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/admin_dashboard.css">
	<link rel="stylesheet" href="css/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
</head>
<body>

        <div class="container-fluid">
            <div class="row d-flex" style="margin-top:20px;">
            <div class="col col-sm-12 col-md-12 col-lg-3 col-xxl-2" >

			<?php require("../admin/student_profile_navbar.php"); ?>
            </div>

            <div class="col col-sm-12 col-md-12 col-lg-9 col-xxl-10">
            <div class="student_profile">
						<h1 style="color:#65BDB6;"><i class="fa-solid fa-user px-2" style="font-size:35px"></i>Student Personal Info<small> Statistics Overview</small></h1>
						<nav style="--bs-breadcrumb-divider: '';" aria-label="breadcrumb">
						<ol style="background-color:#f5f5f5;" class="breadcrumb  px-2 pt-2 py-2">
							<li class="breadcrumb-item"><a style="font-size:18px;color:#65BDB6;" href="admin_index.php?page=admin_dashboard " class="text-decoration-none"><i class="fa-solid fa-gauge px-2" style="font-size:18px;color:#65BDB6;"></i>Dashboard</a></li>
							<li class="breadcrumb-item"><a style="font-size:18px;color:#65BDB6;" href="" class="text-decoration-none"><i class="fa-solid fa-user px-2" style="font-size:18px;color:#65BDB6;"></i>Personal Information</a></li>
						</ol>
						</nav>
			        </div>
          
<div class="row">
<div class="personal_info col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6">
<table class="table table-bordered">
<tr>
<th>Student id</th>
<td></td>
</tr>
<tr>
<th>Student Name</th>
<td></td>
</tr>
<tr>
<th>Father's Name</th>
<td></td>
</tr>
<tr>
<th>Mother's Name</th>
<td></td>
</tr>
<tr>
<tr>
<th>Guardian</th>
<td></td>
</tr>
<th>Relation with Guardian</th>
<td></td>
</tr>
<th>Occupation Of  Guardian</th>
<td></td>
</tr></td>
</tr>
<tr>
<th>Student Number</th>
<td></td>
</tr>
<th>Guardian Number</th>
<td></td>
</tr>
<tr>
<th>Blood Group</th>
<td></td>
</tr>
<tr>
<th>Admission Date</th>
<td></td>
</tr>
</table>




</div>
<div class="personal_info col-sm-12 col-md-12 col-lg-6 col-xxl-6">
<?php 
	if(isset($_POST['photo_update'])){
		$student_photo=$_FILES['photo']['name'];
		  $photo_tmp=$_FILES['photo']['tmp_name'];
		$photo_update=mysqli_query($db_con,"UPDATE `admission_form` SET `photo`='$student_photo' WHERE `id`='$student_id'");
		if($photo_update){
		  move_uploaded_file($photo_tmp,'images/'.$student_photo);
		  echo "<script>
		  alert('Your photo successfully updated!');
		  window.location.href='admin_index.php?page=student_admin_index';
		</script>";
		$student_photo=false;
		}
		else{
		  echo "<script>
		  alert('Photo update failed!');
		  window.location.href='admin_index.php?page=student_admin_index';
		</script>";
		}
	  }
	
	?>
<form action="" method="POST" enctype="multipart/form-data">
    <img class="img-thumbnail" style="width:220px;height:220px;" src="images/ <?=$student_admin_data['photo'];?>" alt=""><br>
    <label for="photo" class="form-label">Profile Picture</label>
    <input type="file" class="form-control" name="photo" id="photo" required style="width:30%;" >
    <br>
    <button type="submit" name="photo_update"  class="btn btn-primary">Change Profile</button>
</form>
</div>



</div>      
     </div>
    </div>
    </div>
    
</body>
</html>